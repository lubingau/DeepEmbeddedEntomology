#include <malloc.h>
#include <stdio.h>
#include <unistd.h>

#include "xparameters.h"
#include "xgpio.h"

#include "platform/platform.h"
#include "console/console.h"
#include "console/stopwatch.h"

#include "model/model_execution.h"
#include "model/dataset.h"

int main() {
	init_platform();
	console_reset_foreground_color();
	console_reset_background_color();
	xil_printf("\r\nSTART\r\n");

	// GPIO initialization
	XGpio gpio;
	XGpio_Initialize(&gpio, XPAR_AXI_GPIO_0_DEVICE_ID);
	xil_printf("[INFO] GPIO initialized\n\r");

	// Mount the SD card
	FATFS fatfs;
	FRESULT res = f_mount(&fatfs, "0:", 0);
	if (res != FR_OK) {
		xil_printf(ANSI_COLOR_RED "[ERROR] Error mounting SD card: %d\n\r" ANSI_COLOR_RESET, res);
		tensil_error_print(TENSIL_FS_ERROR(res));
		return 0;
	}
	xil_printf("[INFO] SD card mounted\n\r");

	// Model loading
	tensil_error_t error = TENSIL_ERROR_NONE;
	struct tensil_driver driver;
	struct tensil_model model;
	error = load_model(MODEL_FILE_PATH, &driver, &model);
	if (error) {
		xil_printf(ANSI_COLOR_RED "[ERROR] Failed to load the model\n\r" ANSI_COLOR_RESET);
		tensil_error_print(error);
		return 0;
	}
	const char *input_node = "x:0";
	const char *output_node = "Identity:0";

    while (1) {

		// Read from BTN
		u32 btn = XGpio_DiscreteRead(&gpio, 1);
		// Put on LEDs
		XGpio_DiscreteWrite(&gpio, 2, btn);


		if (btn == 1) {
//			int n_images = 50;
			int n_images = load_dataset(DATASET_FILE_NAME, (u8 *)DATASET_BUFFER_BASE);
//			load_cifar10(DATASET_FILE_NAME, (u8 *)DATASET_BUFFER_BASE, n_images);
//			n_images = 100;

			error = evaluate_model(&driver, &model, input_node, output_node, (u8 *)DATASET_BUFFER_BASE, n_images, IMAGE_TOTAL_PIXELS, N_CLASSES);
			if (error) {
				xil_printf(ANSI_COLOR_RED "[ERROR] Failed to evaluate the model\n\r" ANSI_COLOR_RESET);
				tensil_error_print(error);
				return 0;
			}
		}
    }

    return 0;
}
